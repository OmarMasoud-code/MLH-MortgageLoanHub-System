import java.util.ArrayList;
import java.util.List;

public class MortgageMarket {
    private List<Borrower> borrowers;
    private List<Lender> lenders;
    private List<Property> properties;

    // Constructor
    public MortgageMarket() {
        this.borrowers = new ArrayList<>();
        this.lenders = new ArrayList<>();
        this.properties = new ArrayList<>();
    }

    // Getter methods
    public List<Borrower> getBorrowers() {
        return borrowers;
    }

    public List<Lender> getLenders() {
        return lenders;
    }

    public List<Property> getProperties() {
        return properties;
    }

    // Setter methods
    public void setBorrowers(List<Borrower> borrowers) {
        this.borrowers = borrowers;
    }

    public void setLenders(List<Lender> lenders) {
        this.lenders = lenders;
    }

    public void setProperties(List<Property> properties) {
        this.properties = properties;
    }

    // Method to add a borrower to the mortgage market
    public void addBorrower(Borrower borrower) {
        borrowers.add(borrower);
    }

    // Method to add a lender to the mortgage market
    public void addLender(Lender lender) {
        lenders.add(lender);
    }

    // Method to add a property to the mortgage market
    public void addProperty(Property property) {
        properties.add(property);
    }
}
