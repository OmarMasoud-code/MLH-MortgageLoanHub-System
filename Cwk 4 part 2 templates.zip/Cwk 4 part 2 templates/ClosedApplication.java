public class ClosedApplication extends ProcessedApplication {
    private ClosingDisclosure closingDisclosure;

    // Constructor
    public ClosedApplication(Application application, LoanEstimate loanEstimate, ClosingDisclosure closingDisclosure) {
        super(application, String.valueOf(loanEstimate));
        this.closingDisclosure = closingDisclosure;
    }

    // Getter method
    public ClosingDisclosure getClosingDisclosure() {
        return closingDisclosure;
    }

    // Method to create a closing disclosure
    public void createClosingDisclosure(String closingDate, double closingCosts) {
        closingDisclosure = new ClosingDisclosure("000", closingDate, closingCosts);
    }

    // Method to get total assets
    public double getTotalAssets() {
        return getApplication().calculateTotalAssets(); // Assuming calculateTotalAssets() method exists in Application
    }

    // Method to get total liabilities
    public double getTotalLiabilities() {
        return getApplication().calculateTotalLiabilities(); // Assuming calculateTotalLiabilities() method exists in Application
    }

    // Method to determine status of processed application
    public String determineStatus() {
        Application application = getApplication();
        double totalDebts = application.calculateTotalLiabilities(); // Assuming calculateTotalLiabilities() method exists in Application
        double totalAssets = application.calculateTotalAssets(); // Assuming calculateTotalAssets() method exists in Application

        // Check various conditions to determine status
        if (totalDebts >= totalAssets) {
            return "Rejected: Total debts exceed total assets";
        }
        // Add more conditions as needed

        // If none of the rejection conditions are met, return approved status
        return "Approved";
    }
}

