public class Property {
    private String streetAddress;
    private double expectedSalesPrice;
    private String typeOfHome;
    private double sizeOfProperty;
    private double realEstateTaxes;
    private double homeownerAssociationDues;
    private double value;

    // Constructor
    public Property(String streetAddress, double expectedSalesPrice, String typeOfHome,
                    double sizeOfProperty, double realEstateTaxes, double homeownerAssociationDues, double value) {
        this.streetAddress = streetAddress;
        this.expectedSalesPrice = expectedSalesPrice;
        this.typeOfHome = typeOfHome;
        this.sizeOfProperty = sizeOfProperty;
        this.realEstateTaxes = realEstateTaxes;
        this.homeownerAssociationDues = homeownerAssociationDues;
        this.value = value;
    }

    // Getter methods
    public String getStreetAddress() {
        return streetAddress;
    }

    public double getExpectedSalesPrice() {
        return expectedSalesPrice;
    }

    public String getTypeOfHome() {
        return typeOfHome;
    }

    public double getSizeOfProperty() {
        return sizeOfProperty;
    }

    public double getRealEstateTaxes() {
        return realEstateTaxes;
    }

    public double getHomeownerAssociationDues() {
        return homeownerAssociationDues;
    }

    public double getValue() {
        return value;
    }
}

