import java.util.List;

public class BankAccount {
    private int accountNumber;
    private String accountType;
    private String status;
    private String openDate;
    private List<String> accountHolders;
    private double currentBalance;
    private double averageBalance;
    private double interestRate;
    private double interestPaid;
    private String closedDate;
    private double balanceAtClose;
    private double balance;

    // Constructor
    public BankAccount(int accountNumber, String accountType, String status, String openDate, List<String> accountHolders,
                       double currentBalance, double averageBalance, double interestRate, double interestPaid,
                       String closedDate, double balanceAtClose, double balance) {
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.status = status;
        this.openDate = openDate;
        this.accountHolders = accountHolders;
        this.currentBalance = currentBalance;
        this.averageBalance = averageBalance;
        this.interestRate = interestRate;
        this.interestPaid = interestPaid;
        this.closedDate = closedDate;
        this.balanceAtClose = balanceAtClose;
        this.balance = balance;
    }

    // Getter methods
    public int getAccountNumber() {
        return accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public String getStatus() {
        return status;
    }

    public String getOpenDate() {
        return openDate;
    }

    public List<String> getAccountHolders() {
        return accountHolders;
    }

    public double getCurrentBalance() {
        return currentBalance;
    }

    public double getAverageBalance() {
        return averageBalance;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public double getInterestPaid() {
        return interestPaid;
    }

    public String getClosedDate() {
        return closedDate;
    }

    public double getBalanceAtClose() {
        return balanceAtClose;
    }

    public double getBalance() {
        return balance;
    }
}
