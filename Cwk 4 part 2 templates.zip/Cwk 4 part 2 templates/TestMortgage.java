public class TestMortgage {
    public static void main(String[] args) {
        try {
            // Initialize mortgage market
            MortgageMarket mortgageMarket = new MortgageMarket();


            // Add borrower, lenders, and property to mortgage market
            Borrower borrower = new Borrower(
                    "Omar Masoud",
                    "123-45-6789",
                    "555-123-4567",
                    "1990-01-01",
                    new Employment("ABC Company", "555-123-4567", "15516", 3, "Construction", 170000),
                    new Income(50000, 2000, 1000, 1500, 500, 1000, 2000),
                    new Assets(new Property("123 Main St", 200000.0, "Single Family Home", 1500.0, 500.0, 0.0, 200000.0), 0.0, 0.0),
                    new Debts(1500, 0, 200, 300, 400, 1000, 500, 300, 100),
                    new CreditHistory(1, 2, 0, 3)
            );
            mortgageMarket.addBorrower(borrower);

            Lender lender1 = new Lender(1, 0.3, 0.2, 0.05, 1000, 2000);
            Lender lender2 = new Lender(2, 0.25, 0.15, 0.04, 1200, 2500);
            mortgageMarket.addLender(lender1);
            mortgageMarket.addLender(lender2);

            Property property = new Property("123 Main St", 250000, "Single Family Home", 2000, 3000, 500, 280000);
            mortgageMarket.addProperty(property);

            // Initializing MortgageImplementer
            MortgageImplementer mortgageImplementer = new MortgageImplementer();
            mortgageImplementer.initializeMortgageMarket(1, 1, 2);

            // Making applications
            Application application1 = mortgageImplementer.apply(borrower, property, lender1);
            Application application2 = mortgageImplementer.apply(borrower, property, lender2);

            // Processed applications
            ProcessedApplication processedApplication1 = mortgageImplementer.process(application1);
            ProcessedApplication processedApplication2 = mortgageImplementer.process(application2);

            // Call createLoanEstimate
            processedApplication1.createLoanEstimate(15000, 10000, 5.0);
            processedApplication2.createLoanEstimate(20000, 15000, 3.0);

            // A couple statements for debugging
            System.out.println("LoanEstimate for processedApplication1: " + processedApplication1.getLoanEstimate());
            System.out.println("LoanEstimate for processedApplication2: " + processedApplication2.getLoanEstimate());

            // Compare the loan costs
            double cost1 = processedApplication1.getLoanEstimate().getEstimatedTotalMonthlyPayment();
            double cost2 = processedApplication2.getLoanEstimate().getEstimatedTotalMonthlyPayment();

            // Choose application with the lowest loan costs
            ProcessedApplication chosenApplication;
            if (cost1 < cost2) {
                chosenApplication = processedApplication1;
                mortgageImplementer.close(processedApplication2);
            } else {
                chosenApplication = processedApplication2;
                mortgageImplementer.close(processedApplication1);
            }
        } catch (Exception e) {
            // Handle any exceptions with a message
            System.err.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
