public class Lender {
    private int lenderNumber;
    private double debtToIncomeRatio;
    private double downPaymentRequirement;
    private double interestRate;
    private double lenderFees;
    private double closingCosts;

    // Constructor
    public Lender(int lenderNumber, double debtToIncomeRatio, double downPaymentRequirement,
                  double interestRate, double lenderFees, double closingCosts) {
        this.lenderNumber = lenderNumber;
        this.debtToIncomeRatio = debtToIncomeRatio;
        this.downPaymentRequirement = downPaymentRequirement;
        this.interestRate = interestRate;
        this.lenderFees = lenderFees;
        this.closingCosts = closingCosts;
    }

    // Getter methods
    public int getLenderNumber() {
        return lenderNumber;
    }

    public double getDebtToIncomeRatio() {
        return debtToIncomeRatio;
    }

    public double getDownPaymentRequirement() {
        return downPaymentRequirement;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public double getLenderFees() {
        return lenderFees;
    }

    public double getClosingCosts() {
        return closingCosts;
    }
}
