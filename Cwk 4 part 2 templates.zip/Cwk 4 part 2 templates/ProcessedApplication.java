public class ProcessedApplication extends Application {
    private String status;
    private LoanEstimate loanEstimate;

    public ProcessedApplication(Application application, String status, LoanEstimate loanEstimate) {
        super(application.getApplicationNumber(), application.getBorrower(), application.getLender(), application.getProperty());
        this.status = status;
        this.loanEstimate = loanEstimate;
    }

    public ProcessedApplication(Application application, String status) {
        super(application.getApplicationNumber(), application.getBorrower(), application.getLender(), application.getProperty());
        this.status = status;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LoanEstimate getLoanEstimate() {
        return loanEstimate;
    }

    public void setLoanEstimate(LoanEstimate loanEstimate) {
        this.loanEstimate = loanEstimate;
    }

    public boolean isApproved() {
        return status.equals("Approved");
    }

    public boolean isRejected() {
        return status.equals("Rejected");
    }


    public Application getApplication() {
        return this;
    }

    public void createLoanEstimate(double propertyPrice, double lenderFees, double interestRate) {
        System.out.println("Creating Loan Estimate...");
        if (isApproved()) {
            double totalCost = propertyPrice + lenderFees;
            double monthlyPayment = calculateMonthlyPayment(totalCost, interestRate);

            // Assuming the loan term is 30 years
            int loanTerm = 360;

            // Placeholder values for mortgage insurance, estimated escrow, and estimated total monthly payment
            double mortgageInsurance = 100;
            double estimatedEscrow = 200;
            double estimatedTotalMonthlyPayment = monthlyPayment + mortgageInsurance + estimatedEscrow;

            // Creating a new LoanEstimate instance
            this.loanEstimate = new LoanEstimate(
                    getBorrower().getName(),
                    totalCost,
                    loanTerm,
                    interestRate,
                    monthlyPayment,
                    mortgageInsurance,
                    estimatedEscrow,
                    estimatedTotalMonthlyPayment
            );
            System.out.println("Loan Estimate created: " + loanEstimate); // Print the created LoanEstimate
        } else {
            this.loanEstimate = new LoanEstimate("-1", -1, -1, -1, -1, -1, -1, -1);
        }
    }

    private double calculateMonthlyPayment(double totalCost, double interestRate) {
        return totalCost * (interestRate / 12);
    }


    public ClosingDisclosure getClosingDisclosure() {
        return null;
    }

}


