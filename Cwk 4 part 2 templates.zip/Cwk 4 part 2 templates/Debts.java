public class Debts {
    private int currentMortgage;
    private int liens;
    private int alimony;
    private int childSupport;
    private int carLoans;
    private int creditCards;
    private int realEstateTaxes;
    private int homeownerAssocDues;
    private int hazardInsurance;

    // Constructor
    public Debts(int currentMortgage, int liens, int alimony, int childSupport,
                 int carLoans, int creditCards, int realEstateTaxes,
                 int homeownerAssocDues, int hazardInsurance) {
        this.currentMortgage = currentMortgage;
        this.liens = liens;
        this.alimony = alimony;
        this.childSupport = childSupport;
        this.carLoans = carLoans;
        this.creditCards = creditCards;
        this.realEstateTaxes = realEstateTaxes;
        this.homeownerAssocDues = homeownerAssocDues;
        this.hazardInsurance = hazardInsurance;
    }

    // Method to calculate the total amount of debts
    public int calculateTotalDebts() {
        return currentMortgage + liens + alimony + childSupport + carLoans +
                creditCards + realEstateTaxes + homeownerAssocDues + hazardInsurance;
    }

    // Getter methods
    public int getCurrentMortgage() {
        return currentMortgage;
    }

    public int getLiens() {
        return liens;
    }

    public int getAlimony() {
        return alimony;
    }

    public int getChildSupport() {
        return childSupport;
    }

    public int getCarLoans() {
        return carLoans;
    }

    public int getCreditCards() {
        return creditCards;
    }

    public int getRealEstateTaxes() {
        return realEstateTaxes;
    }

    public int getHomeownerAssocDues() {
        return homeownerAssocDues;
    }

    public int getHazardInsurance() {
        return hazardInsurance;
    }
}

