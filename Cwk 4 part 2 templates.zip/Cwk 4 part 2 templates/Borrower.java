public class Borrower {
    private String name;
    private String ssn;
    private String homePhone;
    private String dob;
    private Employment employment;
    private Income income;
    private Assets assets;
    private Debts debts;
    private CreditHistory creditHistory;

    // Constructor
    public Borrower(String name, String ssn, String homePhone, String dob,
                    Employment employment, Income income, Assets assets,
                    Debts debts, CreditHistory creditHistory) {
        this.name = name;
        this.ssn = ssn;
        this.homePhone = homePhone;
        this.dob = dob;
        this.employment = employment;
        this.income = income;
        this.assets = assets;
        this.debts = debts;
        this.creditHistory = creditHistory;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public String getSsn() {
        return ssn;
    }

    public String getHomePhone() {
        return homePhone;
    }

    public String getDob() {
        return dob;
    }

    public Employment getEmployment() {
        return employment;
    }

    public Income getIncome() {
        return income;
    }

    public Assets getAssets() {
        return assets;
    }

    public Debts getDebts() {
        return debts;
    }

    public CreditHistory getCreditHistory() {
        return creditHistory;
    }
}

