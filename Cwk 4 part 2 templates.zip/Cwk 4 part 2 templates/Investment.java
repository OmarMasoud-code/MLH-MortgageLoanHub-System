public class Investment {
    private double value;

    // Constructor
    public Investment(double value) {
        this.value = value;
    }

    // Getter method
    public double getValue() {
        return value;
    }
}
