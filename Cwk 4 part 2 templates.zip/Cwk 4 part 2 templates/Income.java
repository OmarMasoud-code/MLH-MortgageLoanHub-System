public class Income {
    private int baseEmploymentIncome;
    private int overtime;
    private int bonuses;
    private int commissions;
    private int dividendsInterest;
    private int netRentalIncome;


    // Constructor
    public Income(int baseEmploymentIncome, int overtime, int bonuses, int commissions,
                  int dividendsInterest, int netRentalIncome, int other) {
        this.baseEmploymentIncome = baseEmploymentIncome;
        this.overtime = overtime;
        this.bonuses = bonuses;
        this.commissions = commissions;
        this.dividendsInterest = dividendsInterest;
        this.netRentalIncome = netRentalIncome;
    }

    // Getter methods
    public int getBaseEmploymentIncome() {
        return baseEmploymentIncome;
    }

    public int getOvertime() {
        return overtime;
    }

    public int getBonuses() {
        return bonuses;
    }

    public int getCommissions() {
        return commissions;
    }

    public int getDividendsInterest() {
        return dividendsInterest;
    }

    public int getNetRentalIncome() {
        return netRentalIncome;
    }


    // Method to calculate total income
    public int calculateTotalIncome() {
        return baseEmploymentIncome + overtime + bonuses + commissions
                + dividendsInterest + netRentalIncome;
    }
}
