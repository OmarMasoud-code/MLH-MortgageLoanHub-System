import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class MortgageImplementer implements MLH {

    private MortgageMarket mortgageMarket;
    private AtomicInteger applicationCounter = new AtomicInteger(0);

    @Override
    public MortgageMarket initializeMortgageMarket(int numOFBorrowers, int numOFProperties, int numOFLenders) {
        mortgageMarket = new MortgageMarket();
        mortgageMarket.setBorrowers(generateBorrowers(numOFBorrowers));
        mortgageMarket.setProperties(generateProperties(numOFProperties));
        mortgageMarket.setLenders(generateLenders(numOFLenders));
        return mortgageMarket;
    }

    @Override
    public Application apply(Borrower b, Property p, Lender l) {
        int applicationNumber = generateApplicationNumber();
        return new Application(applicationNumber, b, l, p);
    }

    @Override
    public ProcessedApplication process(Application a) {
        return new ProcessedApplication(a, "Approved");
    }

    @Override
    public ClosedApplication close(ProcessedApplication pa) {
        return new ClosedApplication(pa, pa.getLoanEstimate(), pa.getClosingDisclosure());
    }

    //method to generate a unique application number
    private int generateApplicationNumber() {
        return applicationCounter.incrementAndGet();
    }

    //method to generate a list of borrowers
    private List<Borrower> generateBorrowers(int num) {
        List<Borrower> borrowers = new ArrayList<>();
        for (int i = 0; i < num; i++) {
            Employment employment = new Employment("Employer" + i, "123456789", "Street" + i, 2, "Position" + i, 50000);
            Income income = new Income(50000, 5, 1130, 500, 2, 15000, 0);
            Assets assets = new Assets(new Property("15117 Main St", 200000, "Single Family", 1500, 2500, 100, 200000), 0, 0);
            Debts debts = new Debts(1700, 500, 600, 1000, 7000, 3000, 8000, 750, 600);
            CreditHistory creditHistory = new CreditHistory(700, 500, 330, 150);

            Borrower borrower = new Borrower("Borrower " + i, "123-45-6789", "123-456-7890", "01/01/1990", employment, income, assets, debts, creditHistory);
            borrowers.add(borrower);
        }
        return borrowers;
    }


    //method to generate a list of properties
    private List<Property> generateProperties(int num) {
        List<Property> properties = new ArrayList<>();
        for (int i = 0; i < num; i++) {
            properties.add(new Property("15117 Ave " + i, 15.0, "Modern", 5000, 5.0, 10.0, 500000.00));

        }
        return properties;
    }

    //method to generate a list of lenders
    private List<Lender> generateLenders(int num) {
        List<Lender> lenders = new ArrayList<>();
        for (int i = 0; i < num; i++) {
            lenders.add(new Lender(i, 0.3, 0.2, 0.05, 1000, 2000));
        }
        return lenders;
    }
}

