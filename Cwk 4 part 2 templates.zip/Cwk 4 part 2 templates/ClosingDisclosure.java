public class ClosingDisclosure {
    private String loanId;
    private String closingDate;
    private double closingCosts;

    // Constructor
    public ClosingDisclosure(String loanId, String closingDate, double closingCosts) {
        this.loanId = loanId;
        this.closingDate = closingDate;
        this.closingCosts = closingCosts;
    }

    // Getter methods
    public String getLoanId() {
        return loanId;
    }

    public String getClosingDate() {
        return closingDate;
    }

    public double getClosingCosts() {
        return closingCosts;
    }

    // Method to calculate closing costs based on the loan amount
    public double calculateClosingCosts(double loanAmount) {
        // Average closing costs for the buyer typically range between 2% and 6% of the loan amount
        return loanAmount * 0.02; // Adjust this calculation based on actual closing costs
    }


}

