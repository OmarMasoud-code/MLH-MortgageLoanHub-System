public class Employment {
    private String employerName;
    private String phone;
    private String streetAddress;
    private int lengthOfTime;
    private String positionTitle;
    private int salary;

    // Constructor
    public Employment(String employerName, String phone, String streetAddress,
                      int lengthOfTime, String positionTitle, int salary) {
        this.employerName = employerName;
        this.phone = phone;
        this.streetAddress = streetAddress;
        this.lengthOfTime = lengthOfTime;
        this.positionTitle = positionTitle;
        this.salary = salary;
    }

    // Getter methods
    public String getEmployerName() {
        return employerName;
    }

    public String getPhone() {
        return phone;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public int getLengthOfTime() {
        return lengthOfTime;
    }

    public String getPositionTitle() {
        return positionTitle;
    }

    public int getSalary() {
        return salary;
    }
}

