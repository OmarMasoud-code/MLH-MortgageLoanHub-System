public class LoanEstimate {
    private String applicantName;
    private double loanAmount;
    private int loanTerm;
    private double interestRate;
    private double monthlyPrincipalAndInterest;
    private double mortgageInsurance;
    private double estimatedEscrow;
    private double estimatedTotalMonthlyPayment;

    // Constructor
    public LoanEstimate(String applicantName, double loanAmount, int loanTerm, double interestRate,
                        double monthlyPrincipalAndInterest, double mortgageInsurance,
                        double estimatedEscrow, double estimatedTotalMonthlyPayment) {
        this.applicantName = applicantName;
        this.loanAmount = loanAmount;
        this.loanTerm = loanTerm;
        this.interestRate = interestRate;
        this.monthlyPrincipalAndInterest = monthlyPrincipalAndInterest;
        this.mortgageInsurance = mortgageInsurance;
        this.estimatedEscrow = estimatedEscrow;
        this.estimatedTotalMonthlyPayment = estimatedTotalMonthlyPayment;
    }


    // Getter methods
    public String getApplicantName() {
        return applicantName;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public int getLoanTerm() {
        return loanTerm;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public double getMonthlyPrincipalAndInterest() {
        return monthlyPrincipalAndInterest;
    }

    public double getMortgageInsurance() {
        return mortgageInsurance;
    }

    public double getEstimatedEscrow() {
        return estimatedEscrow;
    }

    public double getEstimatedTotalMonthlyPayment() {
        return estimatedTotalMonthlyPayment;
    }

    // Override toString method for a clear representation of LoanEstimate in the Test class
    @Override
    public String toString() {
        return "Loan Estimate:\n" +
                "Applicant Name: " + applicantName + "\n" +
                "Loan Amount: " + loanAmount + "\n" +
                "Loan Term: " + loanTerm + "\n" +
                "Interest Rate: " + interestRate + "\n" +
                "Monthly Principal and Interest: " + monthlyPrincipalAndInterest + "\n" +
                "Mortgage Insurance: " + mortgageInsurance + "\n" +
                "Estimated Escrow: " + estimatedEscrow + "\n" +
                "Estimated Total Monthly Payment: " + estimatedTotalMonthlyPayment;
    }
}
