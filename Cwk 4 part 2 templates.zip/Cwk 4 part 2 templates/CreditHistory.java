public class CreditHistory {
    private int bankruptcies;
    private int collections;
    private int foreclosures;
    private int delinquencies;

    // Constructor
    public CreditHistory(int bankruptcies, int collections, int foreclosures, int delinquencies) {
        this.bankruptcies = bankruptcies;
        this.collections = collections;
        this.foreclosures = foreclosures;
        this.delinquencies = delinquencies;
    }

    // Getter methods
    public int getBankruptcies() {
        return bankruptcies;
    }

    public int getCollections() {
        return collections;
    }

    public int getForeclosures() {
        return foreclosures;
    }

    public int getDelinquencies() {
        return delinquencies;
    }
}

