import java.util.ArrayList;
import java.util.List;

public class Assets {
    private List<BankAccount> bankAccounts;
    private Property realProperty;
    private List<Investment> investments;
    private double proceedsFromSale;
    private double giftedFunds;
    private double Amount;

    // Constructor
    public Assets(Property realProperty, double proceedsFromSale, double giftedFunds) {
        this.bankAccounts = new ArrayList<>();
        this.realProperty = realProperty;
        this.investments = new ArrayList<>();
        this.proceedsFromSale = proceedsFromSale;
        this.giftedFunds = giftedFunds;
    }

    // Constructor to initialize Assets with provided bank accounts and investments
    public Assets(List<BankAccount> bankAccounts, Property realProperty, List<Investment> investments, double proceedsFromSale, double giftedFunds) {
        this.bankAccounts = bankAccounts;
        this.realProperty = realProperty;
        this.investments = investments;
        this.proceedsFromSale = proceedsFromSale;
        this.giftedFunds = giftedFunds;
    }

    // Method to add a bank account to the list of bank accounts
    public void addBankAccount(BankAccount bankAccount) {
        bankAccounts.add(bankAccount);
    }

    // Method to add an investment to the list of investments
    public void addInvestment(Investment investment) {
        investments.add(investment);
    }

    // Method to calculate the total value of assets
    public double calculateTotalAssets() {
        double totalAssets = 0;

        for (BankAccount account : bankAccounts) {
            totalAssets += account.getBalance();
        }

        for (Investment investment : investments) {
            totalAssets += investment.getValue();
        }

        totalAssets += realProperty.getValue();
        totalAssets += proceedsFromSale;
        totalAssets += giftedFunds;

        return totalAssets;
    }

    // Getter methods
    public List<BankAccount> getBankAccounts() {
        return bankAccounts;
    }

    public Property getRealProperty() {
        return realProperty;
    }

    public List<Investment> getInvestments() {
        return investments;
    }

    public double getProceedsFromSale() {
        return proceedsFromSale;
    }

    public double getGiftedFunds() {
        return giftedFunds;
    }
    public double getAmount() {
        return Amount;
    }
}

