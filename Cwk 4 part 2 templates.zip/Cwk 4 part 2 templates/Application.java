import java.util.ArrayList;

public class Application {
    private int applicationNumber;
    private Borrower borrower;
    private Lender lender;
    private Property property;
    private ArrayList<Assets> assets;
    private ArrayList<Debts> debts;

    // Constructor
    public Application(int applicationNumber, Borrower borrower, Lender lender, Property property) {
        this.applicationNumber = applicationNumber;
        this.borrower = borrower;
        this.lender = lender;
        this.property = property;
        this.assets = new ArrayList<>();
        this.debts = new ArrayList<>();
    }

    // Getters and setters
    public int getApplicationNumber() {
        return applicationNumber;
    }

    public void setApplicationNumber(int applicationNumber) {
        this.applicationNumber = applicationNumber;
    }

    public Borrower getBorrower() {
        return borrower;
    }

    public void setBorrower(Borrower borrower) {
        this.borrower = borrower;
    }

    public Lender getLender() {
        return lender;
    }

    public void setLender(Lender lender) {
        this.lender = lender;
    }

    public Property getProperty() {
        return property;
    }

    public void setProperty(Property property) {
        this.property = property;
    }

    public ArrayList<Assets> getAssets() {
        return assets;
    }

    public void setAssets(ArrayList<Assets> assets) {
        this.assets = assets;
    }

    public ArrayList<Debts> getDebts() {
        return debts;
    }

    public void setDebts(ArrayList<Debts> debts) {
        this.debts = debts;
    }

    // Method to calculate total assets
    public double calculateTotalAssets() {
        double totalAssets = 0;
        for (Assets asset : assets) {
            totalAssets += asset.getAmount();
        }
        return totalAssets;
    }

    // Method to calculate total liabilities
    public double calculateTotalLiabilities() {
        double totalLiabilities = 0;
        for (Debts debt : debts) {
            totalLiabilities += debt.calculateTotalDebts();
        }
        return totalLiabilities;
    }
}
